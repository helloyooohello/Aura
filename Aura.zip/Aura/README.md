# Prismal Music — liquid-glass music player UI

A native Android music-player screen built with **Prismal**
(`com.github.styropyr0:Prismal:v1.0.1`), the OpenGL-ES glass-morphism
library — used as-is, nothing about its rendering pipeline modified.

Screen: top glass status pill → large album art → glass "now playing"
card (title, artist, `PrismalSlider` progress, shuffle/prev/play‑pause/
next/repeat) → floating glass bottom dock (home/search/library +
`PrismalSwitch`). Every glass surface gets Prismal's calibrated
recipe via `PrismalLiquidGlass.applyBase(view)`, which is the one-call
"exact" material the library ships.

## Build an APK via GitHub

1. Push this folder to a new GitHub repo.
2. It already includes `.github/workflows/build.yml`, so on every push
   to `main`/`master` Actions builds a debug APK and uploads it as a
   workflow artifact (Actions tab → latest run → Artifacts).
3. Or run locally: `gradle assembleDebug` (needs JDK 17 + Android SDK).

## What I confirmed vs. assumed

GitHub's `robots.txt` blocks this tool from fetching the repo's raw
README/TECHNICAL.md directly, so I built this from what turned up in
search snippets. Confirmed from those snippets and used exactly as
shown:

- JitPack coords: `implementation 'com.github.styropyr0:Prismal:v1.0.1'`
- min/target/compile SDK 25 / 36 / 36, Kotlin, OpenGL ES 2.0+
- `PrismalFrameLayout` with `app:pfl_cornerRadius`, `app:pfl_blurRadius`
- `PrismalLiquidGlass.applyBase(view)` — one call, full optical recipe
- `glassCard.setOnClickWithAnimationListener { }` and
  `setClickAnimationPressScale(0.94f)` on `PrismalFrameLayout`
- `clipChildren = false` required on the parent of any
  `PrismalSlider`/`PrismalSwitch`/animated-click `PrismalFrameLayout`
  (the first two set this themselves in `onAttachedToWindow()`)
- Components: `PrismalFrameLayout`, `PrismalIconButton`, `PrismalSwitch`,
  `PrismalSlider`, `PrismalButton`

**Not confirmed** — I could not verify the exact XML attributes for
setting a `PrismalIconButton`'s icon (I used the standard `android:src`
+ `android:padding`, a reasonable but unverified guess), or any
custom listener/attribute names on `PrismalSlider`/`PrismalSwitch`
beyond "they handle their own touch." If the build complains about
those two lines, open the actual repo's sample app or README on
GitHub and swap in the real attribute/method names — the glass
rendering itself (`applyBase`, `pfl_cornerRadius`, `pfl_blurRadius`)
is unaffected either way.
