# Aura — Local Music Player

A glassmorphism-styled Android music player that scans and plays music already
on your phone. Built with Kotlin, Jetpack Compose, and Media3 (ExoPlayer) for
real background playback with lock-screen controls.

## What it does
- Scans your device's music library via `MediaStore` (no manual file picking)
- Plays local audio files with ExoPlayer, in the background, with notification controls
- Glass-panel UI, gradient accents, animated song list, rotating album art, animated mini-player → full player transition

## Get the APK — no local setup required

1. Create a new **public** GitHub repository.
2. Upload every file in this project, preserving the folder structure
   (including the hidden `.github/workflows/build-apk.yml` file).
3. Go to the repo's **Actions** tab. A workflow called "Build APK" will run
   automatically (or click "Run workflow" to trigger it manually).
4. When it finishes (green check, a couple minutes), click into the run →
   scroll to **Artifacts** → download `aura-debug-apk`. Unzip it — that's your
   installable `.apk`.
5. Transfer the APK to your phone (email, Drive, USB) and tap it to install.
   You'll need to allow "install unknown apps" for whatever app you use to open it.

## Build locally instead (optional)
If you'd rather use Android Studio:
1. Install **Android Studio** (free).
2. Open this folder as a project — Android Studio will generate the Gradle
   wrapper automatically the first time it syncs.
3. Click Run ▶, or Build → Build Bundle(s)/APK(s) → Build APK(s).

## Notes
- Minimum Android version: Android 8.0 (API 26).
- First launch asks for permission to read your music library — this is required
  to list your songs.
- This is a real, from-scratch project — expect to tweak/extend it (playlists,
  search, sorting, equalizer, etc.) as you go.
