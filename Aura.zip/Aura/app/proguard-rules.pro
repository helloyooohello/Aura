# Media3/ExoPlayer and Coil both ship their own consumer ProGuard rules
# inside their AARs, so nothing special is required for them here.

# Keep data models that get reflectively touched by MediaStore Cursor
# mapping / Compose stability inference — safe, low-cost keep rule.
-keep class com.example.aura.data.** { *; }

# Standard Kotlin metadata keep so reflection-based libraries (if any get
# added later) can still see Kotlin-specific signatures.
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
