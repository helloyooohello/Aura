plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    // Applies the Compose compiler as its own Gradle plugin — required now
    // that the Compose runtime here (via the BOM below) is far enough ahead
    // that it needs a Kotlin 2.x compose compiler rather than the old
    // `composeOptions { kotlinCompilerExtensionVersion = ... }` approach.
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.aura"
    // Haze (and transitively, current AndroidX/Compose) requires compiling
    // against API 36, which in turn requires AGP 8.9.1+ — see the version
    // bumps in the root build.gradle.kts and the pinned Gradle wrapper.
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.aura"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures {
        compose = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildTypes {
        release {
            // Strips unused code/resources and obfuscates+compacts what's left.
            // This is the single biggest lever for APK size with no behavior
            // change, as long as proguard-rules.pro doesn't need extra keep
            // rules for reflection-based libraries (Coil/Media3 ship their
            // own consumer rules, so this should work out of the box).
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // Bumped from 2024.06.00: Haze's own dependency graph pulls in much newer
    // Compose/AndroidX artifacts (material3 1.4+, compose-ui 1.10+, activity
    // 1.12+, core-ktx 1.16+), and an older BOM doesn't win a version conflict
    // against those, it just fails an AAR-metadata check on compileSdk/AGP.
    // Pinning a current BOM here keeps every androidx.compose.* artifact on
    // one consistent, tested set of versions again.
    implementation(platform("androidx.compose:compose-bom:2026.04.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.12.2")
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.4")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.4")

    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-session:1.4.1")
    implementation("androidx.media3:media3-common:1.4.1")

    implementation("io.coil-kt:coil-compose:2.6.0")

    // Real backdrop/Gaussian blur for the glass surfaces + the Library->Playing
    // transition scrim. Chosen over a heavier OpenGL glass engine (e.g. Prismal,
    // which is a View/XML-based library, not built for Compose) because Haze:
    //  - is a couple hundred KB, not a GPU shader engine, so it barely moves APK size
    //  - hooks into RenderEffect on Android 12+ for hardware-accelerated blur
    //  - degrades automatically to a flat tint (no per-frame blur cost) on our
    //    minSdk 26 devices instead of crashing or forcing a minSdk bump
    implementation("dev.chrisbanes.haze:haze:1.7.2")
    implementation("dev.chrisbanes.haze:haze-materials:1.7.2")

    debugImplementation("androidx.compose.ui:ui-tooling")
}
