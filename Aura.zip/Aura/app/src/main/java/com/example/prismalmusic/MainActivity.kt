package com.example.prismalmusic

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.matrix.prismal.PrismalFrameLayout
import com.matrix.prismal.PrismalLiquidGlass

class MainActivity : AppCompatActivity() {

    private var isPlaying = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val topBar = findViewById<PrismalFrameLayout>(R.id.top_bar)
        val playerCard = findViewById<PrismalFrameLayout>(R.id.player_card)
        val playPause = findViewById<PrismalFrameLayout>(R.id.btn_play_pause)
        val bottomDock = findViewById<PrismalFrameLayout>(R.id.bottom_dock)

        // Apply Prismal's calibrated liquid-glass optical recipe, unmodified,
        // to every glass surface in the screen.
        PrismalLiquidGlass.applyBase(topBar)
        PrismalLiquidGlass.applyBase(playerCard)
        PrismalLiquidGlass.applyBase(playPause)
        PrismalLiquidGlass.applyBase(bottomDock)

        // PrismalFrameLayout cards using setOnClickWithAnimationListener need
        // their parent's clipChildren disabled, per Prismal's docs.
        (playPause.parent as? android.view.ViewGroup)?.clipChildren = false

        val iconPlayPause = findViewById<android.widget.ImageView>(R.id.icon_play_pause)

        playPause.setOnClickWithAnimationListener {
            isPlaying = !isPlaying
            iconPlayPause.setImageResource(
                if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
            )
        }
        playPause.setClickAnimationPressScale(0.92f)
    }
}
