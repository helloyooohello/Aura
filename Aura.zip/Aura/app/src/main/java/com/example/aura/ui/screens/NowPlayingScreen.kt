package com.example.aura.ui.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.animation.core.Animatable
import coil.compose.AsyncImage
import com.example.aura.data.Song
import com.example.aura.ui.components.AuraScrubber
import com.example.aura.ui.components.accentBrush
import com.example.aura.ui.components.appleGlassController
import com.example.aura.ui.components.bouncyTap
import com.example.aura.ui.theme.SubtitleStyle
import com.example.aura.ui.theme.TextPrimary

@Composable
fun NowPlayingScreen(
    song: Song,
    isPlaying: Boolean,
    positionMs: Long,
    durationMs: Long,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onCollapse: () -> Unit,
    modifier: Modifier = Modifier
) {
    // No opaque background here on purpose — this screen sits inside
    // AuraBackground, so leaving it transparent lets the ambient "artwork
    // bleed" (pink/green radial bursts) show through behind the glass
    // controls instead of being covered by a second, flatter gradient.
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 28.dp, vertical = 20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterVertically)
                    .clip(CircleShape)
                    .bouncyTap(onClick = onCollapse, pressedScale = 0.85f)
                    .padding(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.KeyboardArrowDown,
                    contentDescription = "Collapse",
                    tint = TextPrimary
                )
            }
        }

        // Static album art — no spin. Rounded square with a real drop
        // shadow for lift, matching Apple Music's "Now Playing" cover
        // treatment. Pops in with a springy overshoot each time this song
        // becomes the one on screen, echoing the liquid-glass sheet's bounce.
        val artScale = remember(song.id) { Animatable(0.85f) }
        LaunchedEffect(song.id) {
            artScale.animateTo(
                targetValue = 1f,
                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
            )
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 24.dp, start = 12.dp, end = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            AsyncImage(
                model = song.albumArtUri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .scale(artScale.value)
                    .shadow(elevation = 24.dp, shape = RoundedCornerShape(16.dp), clip = false)
                    .clip(RoundedCornerShape(16.dp))
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = song.title,
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
            Text(
                text = song.artist,
                style = SubtitleStyle,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        var isDragging by remember { mutableStateOf(false) }
        var dragProgress by remember { mutableStateOf(0f) }
        // Live duration from the player, not the (possibly stale) Song object,
        // so the bar is always correct for whatever is actually loaded.
        val duration = durationMs.coerceAtLeast(1L)
        val progress = if (isDragging) dragProgress else (positionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)

        AuraScrubber(
            progress = progress,
            onSeekStart = { isDragging = true },
            onSeek = { dragProgress = it },
            onSeekFinished = {
                onSeek((dragProgress * duration).toLong())
                isDragging = false
            },
            modifier = Modifier.padding(top = 28.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                formatMs(if (isDragging) (dragProgress * duration).toLong() else positionMs),
                style = MaterialTheme.typography.labelSmall
            )
            Text(formatMs(durationMs), style = MaterialTheme.typography.labelSmall)
        }

        // Transport controls float in their own glass controller pill,
        // rather than sitting directly on the ambient background.
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 24.dp)
                .appleGlassController(cornerRadius = 40.dp)
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onPrevious, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = TextPrimary, modifier = Modifier.size(30.dp))
            }

            Box(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .size(64.dp)
                    .shadow(elevation = 12.dp, shape = CircleShape, clip = false)
                    .clip(CircleShape)
                    .background(accentBrush())
                    .bouncyTap(onClick = onTogglePlay, pressedScale = 0.88f),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = "Play/Pause",
                    tint = Color.White,
                    modifier = Modifier.size(30.dp)
                )
            }

            IconButton(onClick = onNext, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = TextPrimary, modifier = Modifier.size(30.dp))
            }
        }
    }
}

private fun formatMs(ms: Long): String {
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
