package com.example.aura.ui.theme

import androidx.compose.ui.graphics.Color

// Deep canvas backdrop — closer to true black than pure #000 so the accent
// bursts in AuraBackground's "artwork bleed" have room to glow without
// ever feeling like a flat colored screen.
val BgTop = Color(0xFF08080A)
val BgMid = Color(0xFF08080A)
val BgBottom = Color(0xFF08080A)

// Two-tone accent system: Apple Music pink drives primary controls, Spotify
// green appears only in the ambient background bleed — never both on the
// same control at once, so it reads as "Apple engineered Spotify" rather
// than a mashup.
val AccentPink = Color(0xFFFA243C)
val AccentGreen = Color(0xFF1ED760)

// Back-compat aliases — kept so existing call sites (Theme.kt, accentBrush())
// don't need to change just because the palette moved.
val AccentStart = AccentPink
val AccentMid = AccentPink
val AccentEnd = AccentPink

// "Liquid glass" panel material — ultra-dark translucent onyx (not a light
// iOS frost), so artwork bleed shows through faintly instead of washing out.
val GlassFill = Color(0x73161618)
val GlassFillStrong = Color(0x73161618)
val GlassBorder = Color(0x26FFFFFF)

// Floating controller material — for elements that sit on top of content
// rather than artwork (mini player, transport bar): denser fill, full
// hairline border instead of a top-only specular highlight.
val ControllerFill = Color(0x99242426)
val ControllerBorder = Color(0x14FFFFFF) // white @ 8% alpha

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF98989D)
val TextMuted = Color(0xFF636366)
