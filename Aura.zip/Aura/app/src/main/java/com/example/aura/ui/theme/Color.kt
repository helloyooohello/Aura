package com.example.aura.ui.theme

import androidx.compose.ui.graphics.Color

// Deep space background gradient
val BgTop = Color(0xFF0B0A17)
val BgMid = Color(0xFF14102B)
val BgBottom = Color(0xFF1D1338)

// Accent gradient — violet to hot pink to coral, very "premium app" feel
val AccentStart = Color(0xFF7C4DFF)
val AccentMid = Color(0xFFE93E9E)
val AccentEnd = Color(0xFFFF7A59)

val GlassFill = Color(0x1AFFFFFF)      // translucent white for glass panels
val GlassFillStrong = Color(0x33FFFFFF)
val GlassBorder = Color(0x40FFFFFF)

val TextPrimary = Color(0xFFF5F3FF)
val TextSecondary = Color(0xFFB4AEC9)
val TextMuted = Color(0xFF7B7594)
