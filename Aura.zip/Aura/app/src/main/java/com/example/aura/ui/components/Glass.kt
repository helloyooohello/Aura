package com.example.aura.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.aura.ui.theme.AccentGreen
import com.example.aura.ui.theme.AccentPink
import com.example.aura.ui.theme.BgBottom
import com.example.aura.ui.theme.BgMid
import com.example.aura.ui.theme.BgTop
import com.example.aura.ui.theme.ControllerBorder
import com.example.aura.ui.theme.ControllerFill
import com.example.aura.ui.theme.GlassFill
import com.example.aura.ui.theme.GlassFillStrong
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeStyle
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.hazeEffect
import dev.chrisbanes.haze.hazeSource

/**
 * Shared blur source/state for the whole app. Any screen content wrapped in
 * [AuraBackground] is registered as the thing that gets sampled and blurred;
 * any surface using [appleGlassPanel]/[appleGlassController] reads whatever
 * is currently behind it through this same state. Nullable so previews/tests
 * that don't provide it still compile down to the old flat-fill look.
 */
val LocalAuraHazeState = staticCompositionLocalOf<HazeState?> { null }

/**
 * Ambient background — the base layer that everything else (library list,
 * album art, glass panels) sits on top of, and the thing real Gaussian blur
 * samples from when a glass surface is drawn above it. Two static, low-alpha
 * radial bursts (Apple pink upper-left, Spotify green lower-right) give the
 * blur something warm and organic to pick up instead of blurring flat black.
 */
@Composable
fun AuraBackground(content: @Composable () -> Unit) {
    val hazeState = LocalAuraHazeState.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BgTop, BgMid, BgBottom)))
            .let { if (hazeState != null) it.hazeSource(state = hazeState) else it }
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(AccentPink.copy(alpha = 0.20f), Color.Transparent),
                        center = Offset(120f, 260f),
                        radius = 1100f
                    )
                )
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(AccentGreen.copy(alpha = 0.16f), Color.Transparent),
                        center = Offset(1000f, 1900f),
                        radius = 1300f
                    )
                )
        )
        content()
    }
}

/**
 * "Liquid glass" panel material: real-time Gaussian blur of whatever is
 * behind it (via Haze/RenderEffect on Android 12+), an ultra-dark
 * translucent onyx tint so it reads as glass rather than frost, a hairline
 * top specular edge, and a soft drop shadow for lift.
 *
 * On pre-12 devices Haze automatically swaps the live blur for a flat
 * [GlassFillStrong] tint — same call site, no per-device branching needed,
 * and no per-frame blur cost paid on those devices.
 */
@Composable
fun Modifier.appleGlassPanel(cornerRadius: Dp = 16.dp, borderAlpha: Float = 1f): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    val hazeState = LocalAuraHazeState.current
    val base = this
        .shadow(elevation = 16.dp, shape = shape, clip = false)
        .clip(shape)

    val blurred = if (hazeState != null) {
        base.hazeEffect(
            state = hazeState,
            style = HazeStyle(
                backgroundColor = BgTop,
                tints = listOf(HazeTint(GlassFill)),
                blurRadius = 26.dp,
                noiseFactor = 0.12f,
                fallbackTint = HazeTint(GlassFillStrong)
            )
        )
    } else {
        base.background(GlassFill, shape)
    }

    return blurred.border(
        width = 1.dp,
        brush = Brush.verticalGradient(
            colors = listOf(
                Color.White.copy(alpha = 0.15f * borderAlpha),
                Color.Transparent
            )
        ),
        shape = shape
    )
}

/**
 * Floating controller material: for elements that sit on top of content
 * rather than artwork — the mini player bar, the Now Playing transport
 * pill. Denser blur tint than a glass panel and a full hairline border,
 * since it doesn't need to read as "hovering over" anything in particular.
 */
@Composable
fun Modifier.appleGlassController(cornerRadius: Dp = 24.dp): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    val hazeState = LocalAuraHazeState.current
    val base = this.clip(shape)

    val blurred = if (hazeState != null) {
        base.hazeEffect(
            state = hazeState,
            style = HazeStyle(
                backgroundColor = BgTop,
                tints = listOf(HazeTint(ControllerFill)),
                blurRadius = 22.dp,
                noiseFactor = 0.1f,
                fallbackTint = HazeTint(ControllerFill)
            )
        )
    } else {
        base.background(ControllerFill, shape)
    }

    return blurred.border(width = 1.dp, color = ControllerBorder, shape = shape)
}

/** Composable wrapper around [appleGlassPanel] for call sites that prefer a widget. */
@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 16.dp,
    borderAlpha: Float = 1f,
    content: @Composable () -> Unit
) {
    Box(modifier = modifier.appleGlassPanel(cornerRadius, borderAlpha)) {
        content()
    }
}

/** Accent brush — used sparingly (progress fill, play button, highlights). */
fun accentBrush() = Brush.horizontalGradient(listOf(AccentPink, AccentPink))

/**
 * Custom scrubber: an ultra-thin 4dp track that thickens to 8dp while the
 * user is actively dragging, with a solid white thumb — the Apple Music
 * silhouette rather than Material's default Slider chrome.
 *
 * [onSeek] fires continuously while dragging (for a live time label) and
 * [onSeekFinished] fires once on release, mirroring the drag/commit split
 * the ViewModel's seek call expects.
 */
@Composable
fun AuraScrubber(
    progress: Float,
    onSeekStart: () -> Unit = {},
    onSeek: (Float) -> Unit,
    onSeekFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isActive by remember { mutableStateOf(false) }

    val trackHeight by animateDpAsState(if (isActive) 8.dp else 4.dp, label = "scrubberTrackHeight")
    val thumbSize by animateDpAsState(if (isActive) 16.dp else 12.dp, label = "scrubberThumbSize")

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(28.dp)
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = {
                        isActive = true
                        onSeekStart()
                    },
                    onDragEnd = {
                        isActive = false
                        onSeekFinished()
                    },
                    onDragCancel = {
                        isActive = false
                        onSeekFinished()
                    },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        onSeek((change.position.x / size.width.toFloat()).coerceIn(0f, 1f))
                    }
                )
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { offset ->
                        onSeek((offset.x / size.width.toFloat()).coerceIn(0f, 1f))
                        onSeekFinished()
                    }
                )
            },
        contentAlignment = Alignment.CenterStart
    ) {
        val thumbTravel = maxWidth - thumbSize
        val clamped = progress.coerceIn(0f, 1f)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(trackHeight)
                .clip(RoundedCornerShape(50))
                .background(Color.White.copy(alpha = 0.18f))
        )
        Box(
            modifier = Modifier
                .fillMaxWidth(clamped)
                .height(trackHeight)
                .clip(RoundedCornerShape(50))
                .background(Color.White)
        )
        Box(
            modifier = Modifier
                .offset(x = thumbTravel * clamped)
                .size(thumbSize)
                .clip(CircleShape)
                .background(Color.White)
        )
    }
}
