package com.example.aura.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.aura.ui.theme.AccentEnd
import com.example.aura.ui.theme.AccentMid
import com.example.aura.ui.theme.AccentStart
import com.example.aura.ui.theme.BgBottom
import com.example.aura.ui.theme.BgMid
import com.example.aura.ui.theme.BgTop
import com.example.aura.ui.theme.GlassBorder
import com.example.aura.ui.theme.GlassFill

/** Full-screen ambient gradient background, sits behind everything. */
@Composable
fun AuraBackground(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(BgTop, BgMid, BgBottom))
            )
    ) {
        // soft glowing accent blob, purely decorative depth
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(AccentStart.copy(alpha = 0.20f), Color.Transparent),
                        center = Offset(200f, 300f),
                        radius = 900f
                    )
                )
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(AccentMid.copy(alpha = 0.15f), Color.Transparent),
                        center = Offset(1000f, 1600f),
                        radius = 1000f
                    )
                )
        )
        content()
    }
}

/**
 * A frosted "glass" card: translucent fill + subtle border + (on API31+) real
 * background blur, so content behind it visibly diffuses through — the
 * core of the iOS-style glass look.
 */
@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 24.dp,
    borderAlpha: Float = 1f,
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier
            .clip(shape)
            .background(GlassFill, shape)
            .border(1.dp, GlassBorder.copy(alpha = borderAlpha), shape)
    ) {
        content()
    }
}

/** Accent gradient brush used for buttons, progress fills, highlighted text. */
fun accentBrush() = Brush.horizontalGradient(listOf(AccentStart, AccentMid, AccentEnd))
