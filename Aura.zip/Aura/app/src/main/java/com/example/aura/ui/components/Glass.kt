package com.example.aura.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.aura.ui.theme.AccentGreen
import com.example.aura.ui.theme.AccentPink
import com.example.aura.ui.theme.BgBottom
import com.example.aura.ui.theme.BgMid
import com.example.aura.ui.theme.BgTop
import com.example.aura.ui.theme.ControllerBorder
import com.example.aura.ui.theme.ControllerFill
import com.example.aura.ui.theme.GlassFill

/**
 * Ambient background — the "artwork bleed" effect without a real-time
 * runtime blur. A near-black canvas with two static, low-alpha radial
 * bursts (Apple pink upper-left, Spotify green lower-right) so every glass
 * panel floating on top has some warmth behind it, at essentially zero
 * GPU/RAM cost compared to a live blur pass.
 */
@Composable
fun AuraBackground(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BgTop, BgMid, BgBottom)))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(AccentPink.copy(alpha = 0.20f), Color.Transparent),
                        center = Offset(120f, 260f),
                        radius = 1100f
                    )
                )
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(AccentGreen.copy(alpha = 0.16f), Color.Transparent),
                        center = Offset(1000f, 1900f),
                        radius = 1300f
                    )
                )
        )
        content()
    }
}

/**
 * "Liquid glass" panel material: an ultra-dark translucent onyx fill, a
 * hairline top specular edge (painted as a vertical-gradient border, since
 * that's the cheapest way to fake how physical glass catches light from
 * above), and a soft drop shadow for lift.
 *
 * This is a *simulated* glass look, not true real-time backdrop blur —
 * Compose has no built-in way to blur whatever renders behind a composable
 * (Modifier.blur only blurs the composable's own pixels). Real see-through
 * blur would need a third-party library (e.g. "Haze"); ask if you want
 * that added.
 */
fun Modifier.appleGlassPanel(cornerRadius: Dp = 16.dp, borderAlpha: Float = 1f): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    return this
        .shadow(elevation = 16.dp, shape = shape, clip = false)
        .clip(shape)
        .background(GlassFill, shape)
        .border(
            width = 1.dp,
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.15f * borderAlpha),
                    Color.Transparent
                )
            ),
            shape = shape
        )
}

/**
 * Floating controller material: for elements that sit on top of content
 * rather than artwork — the mini player bar, the Now Playing transport
 * pill. Denser fill than a glass panel and a full hairline border, since
 * it doesn't need to read as "hovering over" anything in particular.
 */
fun Modifier.appleGlassController(cornerRadius: Dp = 24.dp): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    return this
        .clip(shape)
        .background(ControllerFill, shape)
        .border(width = 1.dp, color = ControllerBorder, shape = shape)
}

/** Composable wrapper around [appleGlassPanel] for call sites that prefer a widget. */
@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 16.dp,
    borderAlpha: Float = 1f,
    content: @Composable () -> Unit
) {
    Box(modifier = modifier.appleGlassPanel(cornerRadius, borderAlpha)) {
        content()
    }
}

/** Accent brush — used sparingly (progress fill, play button, highlights). */
fun accentBrush() = Brush.horizontalGradient(listOf(AccentPink, AccentPink))

/**
 * Custom scrubber: an ultra-thin 4dp track that thickens to 8dp while the
 * user is actively dragging, with a solid white thumb — the Apple Music
 * silhouette rather than Material's default Slider chrome.
 *
 * [onSeek] fires continuously while dragging (for a live time label) and
 * [onSeekFinished] fires once on release, mirroring the drag/commit split
 * the ViewModel's seek call expects.
 */
@Composable
fun AuraScrubber(
    progress: Float,
    onSeekStart: () -> Unit = {},
    onSeek: (Float) -> Unit,
    onSeekFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isActive by remember { mutableStateOf(false) }

    val trackHeight by animateDpAsState(if (isActive) 8.dp else 4.dp, label = "scrubberTrackHeight")
    val thumbSize by animateDpAsState(if (isActive) 16.dp else 12.dp, label = "scrubberThumbSize")

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(28.dp)
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = {
                        isActive = true
                        onSeekStart()
                    },
                    onDragEnd = {
                        isActive = false
                        onSeekFinished()
                    },
                    onDragCancel = {
                        isActive = false
                        onSeekFinished()
                    },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        onSeek((change.position.x / size.width.toFloat()).coerceIn(0f, 1f))
                    }
                )
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { offset ->
                        onSeek((offset.x / size.width.toFloat()).coerceIn(0f, 1f))
                        onSeekFinished()
                    }
                )
            },
        contentAlignment = Alignment.CenterStart
    ) {
        val thumbTravel = maxWidth - thumbSize
        val clamped = progress.coerceIn(0f, 1f)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(trackHeight)
                .clip(RoundedCornerShape(50))
                .background(Color.White.copy(alpha = 0.18f))
        )
        Box(
            modifier = Modifier
                .fillMaxWidth(clamped)
                .height(trackHeight)
                .clip(RoundedCornerShape(50))
                .background(Color.White)
        )
        Box(
            modifier = Modifier
                .offset(x = thumbTravel * clamped)
                .size(thumbSize)
                .clip(CircleShape)
                .background(Color.White)
        )
    }
}
