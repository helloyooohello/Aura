package com.example.aura.playback

import android.app.Application
import android.content.ComponentName
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.aura.data.MusicScanner
import com.example.aura.data.Song
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class PlayerViewModel(application: Application) : AndroidViewModel(application) {

    private var controller: MediaController? = null

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs.asStateFlow()

    // Real duration reported by the player for whatever track is actually
    // loaded right now, instead of trusting stale MediaStore metadata for
    // whichever song the UI last thought was playing.
    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    init {
        val context = application.applicationContext
        val sessionToken = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture.addListener({
            val c = controllerFuture.get()
            controller = c

            c.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    _isPlaying.value = isPlaying
                }

                // This is the fix for "previous song still showing": fires the
                // instant ExoPlayer moves to a new item, whether that happened
                // because a song finished naturally (auto-advance), because of
                // next()/previous(), or a seek across item boundaries.
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    syncCurrentFromPlayer()
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    // Duration isn't always known until the player has actually
                    // buffered/prepared the item, so refresh it here too.
                    syncDurationFromPlayer()
                }
            })

            // Catch the case where a controller reconnects to a session that's
            // already mid-playlist (e.g. returning to the app).
            syncCurrentFromPlayer()
            syncDurationFromPlayer()

            startProgressLoop()
        }, MoreExecutors.directExecutor())
    }

    private fun syncCurrentFromPlayer() {
        val c = controller ?: return
        val index = c.currentMediaItemIndex
        _songs.value.getOrNull(index)?.let { song ->
            if (_currentSong.value?.id != song.id) {
                _currentSong.value = song
                // Reset immediately so the old song's position/duration never
                // gets a chance to render against the new song, even for a frame.
                _positionMs.value = c.currentPosition.coerceAtLeast(0L)
            }
        }
        syncDurationFromPlayer()
    }

    private fun syncDurationFromPlayer() {
        val c = controller ?: return
        val playerDuration = c.duration
        if (playerDuration != C.TIME_UNSET && playerDuration > 0) {
            _durationMs.value = playerDuration
        } else {
            _currentSong.value?.let { _durationMs.value = it.durationMs }
        }
    }

    private fun startProgressLoop() {
        viewModelScope.launch {
            while (true) {
                controller?.let { _positionMs.value = it.currentPosition }
                delay(200)
            }
        }
    }

    fun loadLibrary() {
        viewModelScope.launch {
            _songs.value = MusicScanner.scan(getApplication())
        }
    }

    fun play(song: Song) {
        val list = _songs.value
        val index = list.indexOf(song)
        val mediaItems = list.map { MediaItem.fromUri(it.uri) }
        controller?.apply {
            setMediaItems(mediaItems, index, 0L)
            prepare()
            play()
        }
        _currentSong.value = song
        _positionMs.value = 0L
        _durationMs.value = song.durationMs
    }

    fun togglePlayPause() {
        controller?.let {
            if (it.isPlaying) it.pause() else it.play()
        }
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun previous() {
        controller?.seekToPreviousMediaItem()
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        _positionMs.value = ms
    }

    override fun onCleared() {
        controller?.release()
        super.onCleared()
    }
}
