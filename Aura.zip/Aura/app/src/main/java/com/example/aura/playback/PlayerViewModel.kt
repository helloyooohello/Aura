package com.example.aura.playback

import android.app.Application
import android.content.ComponentName
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.aura.data.MusicScanner
import com.example.aura.data.Song
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class PlayerViewModel(application: Application) : AndroidViewModel(application) {

    private var controller: MediaController? = null

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs.asStateFlow()

    init {
        val context = application.applicationContext
        val sessionToken = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture.addListener({
            controller = controllerFuture.get()
            controller?.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    _isPlaying.value = isPlaying
                }
            })
            startProgressLoop()
        }, MoreExecutors.directExecutor())
    }

    private fun startProgressLoop() {
        viewModelScope.launch {
            while (true) {
                controller?.let { _positionMs.value = it.currentPosition }
                delay(300)
            }
        }
    }

    fun loadLibrary() {
        viewModelScope.launch {
            _songs.value = MusicScanner.scan(getApplication())
        }
    }

    fun play(song: Song) {
        val list = _songs.value
        val index = list.indexOf(song)
        val mediaItems = list.map { MediaItem.fromUri(it.uri) }
        controller?.apply {
            setMediaItems(mediaItems, index, 0L)
            prepare()
            play()
        }
        _currentSong.value = song
    }

    fun togglePlayPause() {
        controller?.let {
            if (it.isPlaying) it.pause() else it.play()
        }
    }

    fun next() {
        controller?.seekToNextMediaItem()
        updateCurrentFromIndex()
    }

    fun previous() {
        controller?.seekToPreviousMediaItem()
        updateCurrentFromIndex()
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
    }

    private fun updateCurrentFromIndex() {
        val index = controller?.currentMediaItemIndex ?: return
        _songs.value.getOrNull(index)?.let { _currentSong.value = it }
    }

    override fun onCleared() {
        controller?.release()
        super.onCleared()
    }
}
