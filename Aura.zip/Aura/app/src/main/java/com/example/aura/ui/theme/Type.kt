package com.example.aura.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// The two workhorse styles from the spec — used directly wherever a "track
// title" or "subtitle/artist" moment needs the exact spec values, and as
// the basis for the Typography scale below.
val TrackTitleStyle = TextStyle(
    fontFamily = FontFamily.SansSerif,
    fontWeight = FontWeight.Bold,
    fontSize = 20.sp,
    letterSpacing = (-0.5).sp,
    color = Color.White
)

val SubtitleStyle = TextStyle(
    fontFamily = FontFamily.SansSerif,
    fontWeight = FontWeight.Normal,
    fontSize = 14.sp,
    color = Color.White.copy(alpha = 0.6f)
)

val AuraTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 26.sp,
        letterSpacing = (-0.5).sp,
        color = Color.White
    ),
    // Now Playing title — the prime "track title" spot, spec values verbatim.
    headlineMedium = TrackTitleStyle,
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        letterSpacing = (-0.4).sp,
        color = Color.White
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        letterSpacing = (-0.2).sp,
        color = Color.White
    ),
    // List-row title — same family/weight language as TrackTitleStyle, sized
    // down so dense rows in the library list don't each carry a 20sp headline.
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        letterSpacing = (-0.2).sp,
        color = Color.White
    ),
    // Subtitle/artist — spec values verbatim, used everywhere a subtitle appears.
    bodyMedium = SubtitleStyle,
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 10.5.sp,
        color = Color.White.copy(alpha = 0.6f)
    ),
)
