package com.example.aura

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.aura.playback.PlaybackService
import com.example.aura.playback.PlayerViewModel
import com.example.aura.ui.components.MiniPlayer
import com.example.aura.ui.components.AuraBackground
import com.example.aura.ui.screens.LibraryScreen
import com.example.aura.ui.screens.NowPlayingScreen
import com.example.aura.ui.theme.AuraTheme

class MainActivity : ComponentActivity() {

    private val viewModel: PlayerViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.loadLibrary()
    }

    private val audioPermission: String
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            Manifest.permission.READ_MEDIA_AUDIO
        else
            Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        startService(Intent(this, PlaybackService::class.java))
        ensurePermissionThenLoad()

        setContent {
            AuraTheme {
                Surface(color = androidx.compose.ui.graphics.Color.Transparent) {
                    AuraBackground {
                        AppRoot(viewModel)
                    }
                }
            }
        }
    }

    private fun ensurePermissionThenLoad() {
        val granted = ContextCompat.checkSelfPermission(this, audioPermission) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) {
            viewModel.loadLibrary()
        } else {
            permissionLauncher.launch(audioPermission)
        }
    }
}

@androidx.compose.runtime.Composable
private fun AppRoot(viewModel: PlayerViewModel) {
    val songs by viewModel.songs.collectAsState()
    val currentSong by viewModel.currentSong.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val positionMs by viewModel.positionMs.collectAsState()

    var expanded by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        LibraryScreen(
            songs = songs,
            currentSong = currentSong,
            onSongClick = {
                viewModel.play(it)
                expanded = true
            },
            bottomPadding = if (currentSong != null) 96.dp else 16.dp
        )

        currentSong?.let { song ->
            if (!expanded) {
                val progress = if (song.durationMs > 0) {
                    (positionMs.toFloat() / song.durationMs.toFloat()).coerceIn(0f, 1f)
                } else 0f
                MiniPlayer(
                    song = song,
                    isPlaying = isPlaying,
                    progress = progress,
                    onTogglePlay = { viewModel.togglePlayPause() },
                    onNext = { viewModel.next() },
                    onExpand = { expanded = true },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(12.dp)
                )
            }
        }

        currentSong?.let { song ->
            AnimatedVisibility(
                visible = expanded,
                enter = fadeIn(tween(260)) + slideInVertically(tween(320)) { it / 3 },
                exit = fadeOut(tween(200)) + slideOutVertically(tween(260)) { it / 3 },
                modifier = Modifier.fillMaxSize()
            ) {
                NowPlayingScreen(
                    song = song,
                    isPlaying = isPlaying,
                    positionMs = positionMs,
                    onTogglePlay = { viewModel.togglePlayPause() },
                    onNext = { viewModel.next() },
                    onPrevious = { viewModel.previous() },
                    onSeek = { viewModel.seekTo(it) },
                    onCollapse = { expanded = false }
                )
            }
        }
    }
}
