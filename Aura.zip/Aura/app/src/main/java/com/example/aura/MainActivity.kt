package com.example.aura

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.aura.playback.PlaybackService
import com.example.aura.playback.PlayerViewModel
import com.example.aura.ui.components.LocalAuraHazeState
import com.example.aura.ui.components.MiniPlayer
import com.example.aura.ui.components.AuraBackground
import com.example.aura.ui.screens.LibraryScreen
import com.example.aura.ui.screens.NowPlayingScreen
import com.example.aura.ui.theme.AuraTheme
import com.example.aura.ui.theme.BgTop
import dev.chrisbanes.haze.HazeStyle
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.hazeEffect
import dev.chrisbanes.haze.rememberHazeState

class MainActivity : ComponentActivity() {

    private val viewModel: PlayerViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.loadLibrary()
    }

    private val audioPermission: String
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            Manifest.permission.READ_MEDIA_AUDIO
        else
            Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // True edge-to-edge: draw behind both the status bar and the
        // navigation bar, like every modern Apple/iOS screen does, instead
        // of leaving a plain system-colored gap that isn't part of the app's
        // background. Screens/components handle their own inset padding
        // below so content still avoids sitting under the system bars.
        enableEdgeToEdge()

        startService(Intent(this, PlaybackService::class.java))
        ensurePermissionThenLoad()

        setContent {
            AuraTheme {
                Surface(color = androidx.compose.ui.graphics.Color.Transparent) {
                    AuraBackground {
                        AppRoot(viewModel)
                    }
                }
            }
        }
    }

    private fun ensurePermissionThenLoad() {
        val granted = ContextCompat.checkSelfPermission(this, audioPermission) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) {
            viewModel.loadLibrary()
        } else {
            permissionLauncher.launch(audioPermission)
        }
    }
}

@androidx.compose.runtime.Composable
private fun AppRoot(viewModel: PlayerViewModel) {
    val songs by viewModel.songs.collectAsState()
    val currentSong by viewModel.currentSong.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val positionMs by viewModel.positionMs.collectAsState()
    val durationMs by viewModel.durationMs.collectAsState()

    var expanded by remember { mutableStateOf(false) }

    // Single source of truth for the Library<->Now Playing morph: 0 = fully
    // collapsed (Library), 1 = fully expanded (Now Playing). Every visual of
    // the transition (blur radius, mini player fade/shrink, sheet fade/rise)
    // reads off this one springy value instead of juggling separate
    // AnimatedVisibility timings, so it can never look like two things
    // animating on different clocks.
    val hazeState = rememberHazeState()
    val expandProgress by animateFloatAsState(
        targetValue = if (expanded) 1f else 0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessLow),
        label = "expandProgress"
    )

    CompositionLocalProvider(LocalAuraHazeState provides hazeState) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.systemBars)
        ) {
            LibraryScreen(
                songs = songs,
                currentSong = currentSong,
                onSongClick = {
                    viewModel.play(it)
                    expanded = true
                },
                bottomPadding = if (currentSong != null) 96.dp else 16.dp
            )

            // Real Gaussian blur ramps in behind the Now Playing sheet as it
            // rises, instead of the sheet just sliding on top of sharp
            // library content — this is the "artwork bleed" the glass
            // panels lean on, made literal for the big transition.
            if (expandProgress > 0.001f) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .hazeEffect(
                            state = hazeState,
                            style = HazeStyle(
                                backgroundColor = BgTop,
                                tints = listOf(HazeTint(Color.Black.copy(alpha = 0.30f * expandProgress))),
                                blurRadius = (expandProgress * 40f).dp,
                                noiseFactor = 0.08f
                            )
                        )
                        // Swallow taps so a quick double-tap during the morph can't
                        // reach a library row through the blur.
                        .pointerInput(Unit) { detectTapGestures { } }
                )
            }

            currentSong?.let { song ->
                if (expandProgress < 0.999f) {
                    val duration = if (durationMs > 0) durationMs else song.durationMs
                    val progress = if (duration > 0) {
                        (positionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
                    } else 0f
                    MiniPlayer(
                        song = song,
                        isPlaying = isPlaying,
                        progress = progress,
                        onTogglePlay = { viewModel.togglePlayPause() },
                        onNext = { viewModel.next() },
                        onExpand = { expanded = true },
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(12.dp)
                            .graphicsLayer {
                                // Shrink + fade out as the sheet takes over, rather
                                // than popping away the instant the drag/tap starts.
                                val collapse = 1f - expandProgress
                                alpha = collapse
                                scaleX = 0.9f + 0.1f * collapse
                                scaleY = 0.9f + 0.1f * collapse
                            }
                    )
                }
            }

            currentSong?.let { song ->
                if (expandProgress > 0.001f) {
                    NowPlayingScreen(
                        song = song,
                        isPlaying = isPlaying,
                        positionMs = positionMs,
                        durationMs = if (durationMs > 0) durationMs else song.durationMs,
                        onTogglePlay = { viewModel.togglePlayPause() },
                        onNext = { viewModel.next() },
                        onPrevious = { viewModel.previous() },
                        onSeek = { viewModel.seekTo(it) },
                        onCollapse = { expanded = false },
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                alpha = expandProgress
                                val rise = (1f - expandProgress) * (size.height * 0.12f)
                                translationY = rise
                                val sheetScale = 0.96f + 0.04f * expandProgress
                                scaleX = sheetScale
                                scaleY = sheetScale
                            }
                    )
                }
            }
        }
    }
}
