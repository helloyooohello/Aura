package com.example.aura.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.aura.data.Song
import com.example.aura.ui.components.SongRow
import com.example.aura.ui.components.accentBrush
import com.example.aura.ui.theme.TextSecondary

@Composable
fun LibraryScreen(
    songs: List<Song>,
    currentSong: Song?,
    onSongClick: (Song) -> Unit,
    bottomPadding: androidx.compose.ui.unit.Dp
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.padding(start = 20.dp, top = 28.dp, bottom = 4.dp)) {
            GradientTitle("Your Library")
        }

        if (songs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Text(
                        text = "Scanning for music on your device…",
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(top = 16.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(
                    start = 12.dp,
                    end = 12.dp,
                    top = 4.dp,
                    bottom = bottomPadding
                )
            ) {
                items(
                    items = songs,
                    key = { it.id }
                ) { song ->
                    SongRow(
                        song = song,
                        isCurrent = song.id == currentSong?.id,
                        onClick = { onSongClick(song) }
                    )
                }
            }
        }
    }
}

@Composable
private fun GradientTitle(text: String) {
    val base = MaterialTheme.typography.titleLarge
    Text(
        text = text,
        style = base.copy(brush = accentBrush())
    )
}
