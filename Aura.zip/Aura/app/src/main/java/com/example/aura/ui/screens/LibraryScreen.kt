package com.example.aura.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.aura.data.Song
import com.example.aura.ui.components.SongRow
import com.example.aura.ui.components.accentBrush
import com.example.aura.ui.theme.TextSecondary

@Composable
fun LibraryScreen(
    songs: List<Song>,
    currentSong: Song?,
    onSongClick: (Song) -> Unit,
    bottomPadding: androidx.compose.ui.unit.Dp
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.padding(start = 24.dp, top = 32.dp, bottom = 8.dp)) {
            GradientTitle("Your Library")
        }

        if (songs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Text(
                        text = "Scanning for music on your device…",
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 16.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(
                    start = 16.dp,
                    end = 16.dp,
                    top = 8.dp,
                    bottom = bottomPadding
                )
            ) {
                itemsIndexed(songs) { index, song ->
                    var visible by remember { mutableStateOf(false) }
                    androidx.compose.runtime.LaunchedEffect(song.id) {
                        kotlinx.coroutines.delay((index.coerceAtMost(12)) * 30L)
                        visible = true
                    }
                    AnimatedVisibility(
                        visible = visible,
                        enter = fadeIn(tween(280)) + slideInVertically(
                            animationSpec = tween(280),
                            initialOffsetY = { it / 4 }
                        )
                    ) {
                        SongRow(
                            song = song,
                            isCurrent = song.id == currentSong?.id,
                            onClick = { onSongClick(song) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GradientTitle(text: String) {
    val base = androidx.compose.material3.MaterialTheme.typography.headlineLarge
    Text(
        text = text,
        style = base.copy(brush = accentBrush())
    )
}

private fun <T> androidx.compose.foundation.lazy.LazyListScope.itemsIndexed(
    list: List<T>,
    itemContent: @Composable (Int, T) -> Unit
) {
    items(list.size) { index ->
        itemContent(index, list[index])
    }
}
