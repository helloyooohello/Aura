package com.example.aura.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.semantics.Role

/**
 * The "bubbly Apple" tap: a quick, un-springy dip on press (so it feels
 * responsive, not floaty), then a springy overshoot back past 1x on
 * release (so it feels alive, not just a fade back). That asymmetry — fast
 * down, bouncy up — is what reads as "liquid"/bubbly rather than a plain
 * press-scale.
 *
 * Cheap: no extra layout or composition, just one Animatable-backed float
 * feeding Modifier.scale, so it's fine on list rows.
 */
@Composable
fun Modifier.bouncyTap(
    onClick: () -> Unit,
    pressedScale: Float = 0.94f,
    role: Role? = null
): Modifier {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed) pressedScale else 1f,
        animationSpec = if (isPressed) {
            spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessHigh)
        } else {
            spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium)
        },
        label = "bouncyTapScale"
    )

    return this
        .scale(scale)
        .clickable(
            interactionSource = interactionSource,
            indication = null,
            role = role,
            onClick = onClick
        )
}
