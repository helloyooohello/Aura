plugins {
    id("com.android.application") version "8.9.1" apply false
    id("org.jetbrains.kotlin.android") version "2.1.20" apply false
    // Compose compiler is decoupled from Kotlin's own version since Kotlin 2.0 —
    // needs to be applied explicitly rather than via the old `kotlinCompilerExtensionVersion`.
    id("org.jetbrains.kotlin.plugin.compose") version "2.1.20" apply false
}
