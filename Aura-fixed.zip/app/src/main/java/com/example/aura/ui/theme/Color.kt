package com.example.aura.ui.theme

import androidx.compose.ui.graphics.Color

// True near-black background, layered — the way Apple Music/Music.app do dark mode.
val BgTop = Color(0xFF000000)
val BgMid = Color(0xFF0C0C0E)
val BgBottom = Color(0xFF000000)

// Single refined accent (Apple Music's signature coral-red), used sparingly —
// not a rainbow gradient. This is what makes it read as "Apple made this"
// instead of "generic music app."
val AccentStart = Color(0xFFFA5B6B)
val AccentMid = Color(0xFFFA233B)
val AccentEnd = Color(0xFFFA5B6B)

// Frosted "liquid glass" surfaces: light, translucent, layered — closer to
// iOS material than a flat tinted box.
val GlassFill = Color(0x14FFFFFF)
val GlassFillStrong = Color(0x22FFFFFF)
val GlassBorder = Color(0x26FFFFFF)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF98989D)
val TextMuted = Color(0xFF636366)
