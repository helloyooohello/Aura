package com.example.aura.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.aura.ui.theme.AccentMid
import com.example.aura.ui.theme.BgBottom
import com.example.aura.ui.theme.BgMid
import com.example.aura.ui.theme.BgTop
import com.example.aura.ui.theme.GlassBorder
import com.example.aura.ui.theme.GlassFill
import com.example.aura.ui.theme.GlassFillStrong

/**
 * Full-screen background, sits behind everything. Kept close to true black
 * with one very soft, low-alpha glow — Apple Music's dark mode is almost
 * entirely flat, so restraint here is what sells the "liquid glass" panels
 * floating on top of it.
 */
@Composable
fun AuraBackground(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BgTop, BgMid, BgBottom)))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(AccentMid.copy(alpha = 0.10f), Color.Transparent),
                        center = Offset(500f, 200f),
                        radius = 1400f
                    )
                )
        )
        content()
    }
}

/**
 * A frosted "liquid glass" card: layered translucent fill + a soft top
 * highlight + a hairline border. This is a *simulated* glass look, not a
 * true real-time backdrop blur — Jetpack Compose has no built-in way to
 * blur whatever is rendered behind a composable (Modifier.blur only blurs
 * a composable's own pixels). Real see-through backdrop blur would need a
 * third-party library (e.g. "Haze"); ask if you want that added.
 */
@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 20.dp,
    borderAlpha: Float = 1f,
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)

    Box(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    colors = listOf(GlassFillStrong, GlassFill)
                ),
                shape
            )
            .border(
                width = 0.75.dp,
                color = GlassBorder.copy(alpha = GlassBorder.alpha * borderAlpha),
                shape = shape
            )
    ) {
        content()
    }
}

/** Accent brush — used sparingly (progress fill, play button, highlights). */
fun accentBrush() = Brush.horizontalGradient(listOf(AccentMid, AccentMid))
